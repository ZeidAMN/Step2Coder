﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vererbung
{
    public class SuperHuman: Human            // (human is die mama und superhuman kind )
    {

        string special_ability;

        public SuperHuman()
        {



        }

        public void fight()
        {

            Console.WriteLine("fight started");


        }
        


    }
}
