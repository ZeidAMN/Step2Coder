﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace virtuelle_funktionen02
{
    internal class SuperheroVillain : GameCharacter
    {
        public SuperheroVillain()
        {
            name = "Default SuperheroVillain";
            id = 0;
            healthpoints = 100;
            set_special_ability("None");
        }

        public SuperheroVillain(string name, int id, int healthpoints, string special_ability)
        {
            this.name = name;
            this.id = id;
            this.healthpoints = healthpoints;
            set_special_ability(special_ability);
        }

        public override void fight(GameCharacter gc1, GameCharacter gc2)
        {
            Random rand = new Random();
            int damage = rand.Next(5, 20); // Random damage between 5 and 20
            Console.WriteLine(gc1.name + "attacks " + gc2.name + " with a special move causing " + damage + " damage.");
            gc2.healthpoints -= damage;
            Console.WriteLine(gc2.name + "now has " + gc2.healthpoints + " health points left.");
        }

        public override void printData()
        {
            Console.WriteLine("SuperheroVillain Data: Name: " + name +  "Id: " + id + " HealthPoints: " + healthpoints + " SpecialAbility: " + get_special_ability());
        }
    }
}