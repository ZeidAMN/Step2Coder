﻿Console.OutputEncoding = System.Text.Encoding.UTF8;
/* \u20AC das ist der Unicode um € in der Eingabekonsole zu drucken */
Console.Error.WriteLine("Total Price = (your price) \u20AC");


int choice;  // int auswahl;
int chips_number;
double chips_price;  //Deklaration   //Declaration
int redbull_number;
double redbull_price;
int milka_number;
double milka_price;
double price;
int cigarettes_number;
double cigarettes_price;
int age;

chips_price = 3.50;  // Definition  // Definition  
redbull_price = 2.99;
milka_price = 2.75;
cigarettes_price = 6.50;
age = 18;

do
{

menu:
    Console.WriteLine("Welcome to my vending machine shop - press 1 for Chips or 2 for RedBull or 3 for Milka Chocolate or 4 for Cigarettes and 5 to exit");
    choice = Convert.ToInt32(Console.ReadLine());

    switch (choice)
    {
        case 1:
            Console.WriteLine("How many Chips would you like?");
            chips_number = Convert.ToInt32(Console.ReadLine());
            price = chips_number * chips_price;
            Console.WriteLine("Your total is " + price);
            break;


        case 2:
            Console.WriteLine("How many RedBull would you like?");
            redbull_number = Convert.ToInt32(Console.ReadLine());
            price = redbull_number * redbull_price;
            Console.WriteLine("Your total is " + price);
            break;


        case 3:
            Console.WriteLine("How many Milka Chocolate would you like?");
            milka_number = Convert.ToInt32(Console.ReadLine());
            price = milka_number * milka_price;
            Console.WriteLine("Your total is " + price);
            break;


        case 4:
            Console.WriteLine("How old are you?");
            // reAD.. age = 
            age = Convert.ToInt32(Console.ReadLine());
            if (age > 17)
            {
                Console.WriteLine("The Age matched with the system");
                Console.WriteLine("How many Cigarettes would you like?");
                cigarettes_number = Convert.ToInt32(Console.ReadLine());
                price = cigarettes_price * cigarettes_price;
                Console.WriteLine("Your total is " + price);
            }
            else
            {
                Console.WriteLine("Your under the age of 18");
                goto menu;
            }
            break;


     



    } // ende von switch
} while (choice != 5);
