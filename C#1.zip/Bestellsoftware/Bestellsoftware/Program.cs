﻿int choice;
double price;
int charging_cable_number;
double charging_cable_price;
int headset_number;
double headset_price;
int mouse_number;
double mouse_price;
int e_cigarette_number;
double e_cigarette_price;
int age;

charging_cable_price = 7.99;
headset_price = 9.99;
mouse_price = 6.99;
e_cigarette_price = 14.69;
age = 18;


do
{

menu:
    Console.WriteLine("Welcome to The Store - press 1 for Charging Cable or press 2 for a Headset or 3 for a Mouse or 4 for E-Cigarette and 5 to exit ");
    choice = Convert.ToInt32(Console.ReadLine());

    switch (choice)
    {

            case 1:
            Console.WriteLine("How many Charging Cable would you like?");
            charging_cable_number = Convert.ToInt32(Console.ReadLine());
            price = charging_cable_number * charging_cable_price;
            Console.WriteLine("Your total is " + price);
            break;


            case 2:
            Console.WriteLine("How many Headset would you like?");
            headset_number = Convert.ToInt32(Console.ReadLine());
            price = headset_number*headset_price;
            Console.WriteLine("Your total is " + price);
            break;


            case 3:
            Console.WriteLine("How many Mice would you like?");
            mouse_number = Convert.ToInt32(Console.ReadLine());
            price = mouse_number*mouse_price;
            Console.WriteLine("Your total is " + price);
            break;


            case 4:
            Console.WriteLine("How old are you?");
            age = Convert.ToInt32(Console.ReadLine());
            if (age > 17)
            {
                Console.WriteLine("The Age matched with the system");
                Console.WriteLine("How many E-Cigarette would you like?");
                e_cigarette_number = Convert.ToInt32(Console.ReadLine());
                price = e_cigarette_number*e_cigarette_price;
                Console.WriteLine("Your total is " + price);
            }
            else
            {
                Console.WriteLine("You are Under Age no E-Cigarette for you");
                goto menu;
            }
            break;




    }
} while (choice != 5);