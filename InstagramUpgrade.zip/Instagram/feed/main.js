// Define the API endpoints
const postsApiUrl = "http://212.132.116.39:80/posts";
const commentsApiUrl = "http://212.132.116.39:80/comments";
const likesApiUrl = "http://212.132.116.39:80/likes";

// Function to fetch data from the posts API
async function fetchData() {
    try {
        // Make a GET request to the posts API endpoint
        const response = await fetch(postsApiUrl);

        // Check if the response is successful
        if (!response.ok) {
            throw new Error(`An error occurred: ${response.status}`);
        }

        // Parse the JSON data from the response
        const posts = await response.json();

        // Call the function to display the data
        displayData(posts);
    } catch (error) {
        console.error('Error fetching posts data:', error);
    }
}

// Function to fetch comments for all posts
async function fetchComments() {
    try {
        // Make a GET request to the comments API endpoint
        const response = await fetch(commentsApiUrl);

        // Check if the response is successful
        if (!response.ok) {
            throw new Error(`An error occurred: ${response.status}`);
        }

        // Parse the JSON data from the response
        const comments = await response.json();

        return comments;
    } catch (error) {
        console.error('Error fetching comments:', error);
        return [];
    }
}

// Function to fetch likes for all posts
async function fetchLikes() {
    try {
        // Make a GET request to the likes API endpoint
        const response = await fetch(likesApiUrl);

        // Check if the response is successful
        if (!response.ok) {
            throw new Error(`An error occurred: ${response.status}`);
        }

        // Parse the JSON data from the response
        const likes = await response.json();

        return likes;
    } catch (error) {
        console.error('Error fetching likes:', error);
        return [];
    }
}

// Function to display the fetched data
async function displayData(posts) {
    // Get the feed container element
    const feedContainer = document.getElementById('feed-container');

    // Clear any existing content in the feed container
    feedContainer.innerHTML = '';

    // Fetch all comments and likes
    const allComments = await fetchComments();
    const allLikes = await fetchLikes();

    // Iterate through the list of posts
    for (const post of posts) {
        // Create a card element for each post
        const card = document.createElement('div');
        card.className = 'card';

        // Create an image element
        const img = document.createElement('img');

        // Check if the image is a URL or base64 and set the src accordingly
        img.src = post.bild.startsWith('http') ? post.bild : `data:image/png;base64,${post.bild}`;
        img.alt = post.titel; // Using 'titel' for alt text

        // Create a title element
        const title = document.createElement('div');
        title.className = 'titel';
        title.textContent = post.titel; // Using 'titel'

        // Create a timestamp element
        const timestamp = document.createElement('div');
        timestamp.className = 'timestamp';
        timestamp.textContent = `Posted on: ${new Date(post.create_timestamp).toLocaleDateString()} at ${new Date(post.create_timestamp).toLocaleTimeString()}`;

        // Create a username element
        const username = document.createElement('div');
        username.className = 'benutzername';
        username.textContent = `Posted by: ${post.user}`; // Using 'user'

        // Filter comments for this post using bildID
        const postComments = allComments.filter(comment => comment.bildID === post.id);

        // Create a comments container element
        const commentsContainer = document.createElement('div');
        commentsContainer.className = 'comments';

        // Check if there are comments and display them
        if (postComments.length > 0) {
            postComments.forEach(comment => {
                const commentElement = document.createElement('div');
                commentElement.className = 'comment';

                // Create a comment author element
                const commentAuthor = document.createElement('span');
                commentAuthor.className = 'comment-author';
                commentAuthor.textContent = comment.user;

                // Create a comment text element
                const commentText = document.createElement('span');
                commentText.className = 'comment-text';
                commentText.textContent = `: ${comment.kommentar}`; // Using 'kommentar'

                commentElement.appendChild(commentAuthor);
                commentElement.appendChild(commentText);

                commentsContainer.appendChild(commentElement);
            });
        } else {
            const noComments = document.createElement('div');
            noComments.className = 'comment';
            noComments.textContent = 'No comments yet.';
            commentsContainer.appendChild(noComments);
        }

        // Filter likes for this post using bildID
        const postLikes = allLikes.filter(like => like.bildID === post.id);
        const likeCount = postLikes.length;

        // Check if the current user has liked this post
        const currentUser = localStorage.getItem('username') || 'current_user'; // Replace with your user logic
        const userHasLiked = postLikes.some(like => like.user === currentUser);

        // Create a likes container element
        const likesContainer = document.createElement('div');
        likesContainer.className = 'likes';

        // Create a like button element
        const likeButton = document.createElement('button');
        likeButton.className = 'like-button';
        likeButton.innerHTML = userHasLiked ? '<span class="material-symbols-outlined">favorite</span> Unlike' : '<span class="material-symbols-outlined">favorite</span> Like';

        // Add event listener to like button
        likeButton.addEventListener('click', async () => {
            if (userHasLiked) {
                await unlikePost(post.id);
            } else {
                await postLike(post.id);
            }
            // Refresh the post data after adding or removing a like
            fetchData(); // Call fetchData to refresh the feed
        });

        // Create a likes count element
        const likesCount = document.createElement('span');
        likesCount.className = 'likes-count';
        likesCount.textContent = `${likeCount} Likes`;

        // Append like button and count to the likes container
        likesContainer.appendChild(likeButton);
        likesContainer.appendChild(likesCount);

        // Append elements to the card
        card.appendChild(img);
        card.appendChild(title);
        card.appendChild(timestamp);
        card.appendChild(username);
        card.appendChild(likesContainer);
        card.appendChild(commentsContainer);

        // Create a form to add a new comment
        const commentForm = document.createElement('div');
        commentForm.className = 'comment-form';
        commentForm.innerHTML = `
            <input type="text" placeholder="Your Name" class="comment-user">
            <textarea placeholder="Write a comment..." class="comment-textarea"></textarea>
            <button type="button">Post Comment</button>
        `;

        // Add event listener to the form button to post a comment
        const commentButton = commentForm.querySelector('button');
        commentButton.addEventListener('click', async () => {
            const commentUser = commentForm.querySelector('.comment-user').value.trim();
            const commentText = commentForm.querySelector('.comment-textarea').value.trim();

            if (commentUser && commentText) {
                await postComment(commentText, commentUser, post.id);
                // Refresh comments for this post after adding a new one
                fetchData(); // Call fetchData to refresh the feed
            } else {
                alert('Please enter both a name and a comment.');
            }
        });

        // Append the comment form to the card
        card.appendChild(commentForm);

        // Append the card to the feed container
        feedContainer.appendChild(card);
    }
}

// Function to post a new comment
async function postComment(comment, user, bildID) {
    try {
        const response = await fetch(commentsApiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                kommentar: comment,
                user: user,
                bildID: bildID
            })
        });

        if (!response.ok) {
            throw new Error(`Error posting comment: ${response.status}`);
        }

        console.log('Comment posted successfully');
    } catch (error) {
        console.error('Error posting comment:', error);
    }
}

// Function to post a new like
async function postLike(bildID) {
    try {
        const response = await fetch(likesApiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                bildID: bildID,
                user: localStorage.getItem('username') || 'current_user' // replace 'current_user' with actual user identification if needed
            })
        });

        if (!response.ok) {
            throw new Error(`Error posting like: ${response.status}`);
        }

        console.log('Like posted successfully');
    } catch (error) {
        console.error('Error posting like:', error);
    }
}

// Function to unlike a post
async function unlikePost(bildID) {
    try {
        const currentUser = localStorage.getItem('username') || 'current_user';
        // Find the like by this user for this post
        const response = await fetch(likesApiUrl);
        const allLikes = await response.json();
        const like = allLikes.find(like => like.bildID === bildID && like.user === currentUser);

        if (like) {
            // Send DELETE request to remove the like
            const deleteResponse = await fetch(`${likesApiUrl}/${like.id}`, {
                method: 'DELETE',
            });

            if (!deleteResponse.ok) {
                throw new Error(`Error unliking post: ${deleteResponse.status}`);
            }

            console.log('Unlike successful');
        }
    } catch (error) {
        console.error('Error unliking post:', error);
    }
}

// Function to display a greeting
function displayGreeting() {
    const username = localStorage.getItem('username') || 'Guest';
    const greetingElement = document.getElementById('greeting');
    if (greetingElement) {
        greetingElement.textContent = `Welcome, ${username}!`;
    }
}

// Fetch the data when the page loads and display greeting
window.onload = function () {
    displayGreeting();
    fetchData();
};

// Add event listener to the upload icon
const uploadIcon = document.getElementById('upload-icon');
if (uploadIcon) {
    uploadIcon.addEventListener('click', function () {
        // Redirect to upload.html
        window.location.href = 'upload.html';
    });
}

// Add event listener to the home icon
const homeIcon = document.getElementById('home-icon');
if (homeIcon) {
    homeIcon.addEventListener('click', function () {
        // Redirect to index.html
        window.location.href = 'index.html';
    });
}
