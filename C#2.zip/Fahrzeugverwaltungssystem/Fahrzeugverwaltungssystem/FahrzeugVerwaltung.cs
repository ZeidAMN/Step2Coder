﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fahrzeugverwaltungssystem
{
    internal class FahrzeugVerwaltung
    {
        public static void ZeigeFahrzeugInformationen(Fahrzeug f1)
        {
            f1.BeschreibeFahrzeug();
        }
    }
}
