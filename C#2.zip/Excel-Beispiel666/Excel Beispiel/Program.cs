﻿using System;
using System.IO;
using System.Threading;
using OfficeOpenXml;


namespace Excel_Beispiel
{
    internal class Program
    {
        private static Mutex mutex = new Mutex(); // Mutex für die Datei-Synchronisation
        private static string filePath = @"C:\Users\FP2402199\Downloads\Excel beispiele\output1.xlsx"; // Pfad zur Ausgabedatei
        private static bool stopReading = false; // Flag to stop the reading thread

        public static void WriteToExcel(string input)
        {
            try
            {
                mutex.WaitOne(); // Mutex erwerben, um exklusiven Zugriff zu gewährleisten

                // Excel-Datei öffnen oder erstellen
                FileInfo fileInfo = new FileInfo(filePath);
                using (ExcelPackage package = new ExcelPackage(fileInfo))
                {
                    ExcelWorksheet worksheet;
                    if (package.Workbook.Worksheets.Count == 0)
                    {
                        worksheet = package.Workbook.Worksheets.Add("Sheet1");
                    }
                    else
                    {
                        worksheet = package.Workbook.Worksheets[0];
                    }

                    // Neue Zeile finden und Input schreiben
                    int newRow = worksheet.Dimension?.Rows + 1 ?? 1;
                    worksheet.Cells[newRow, 1].Value = input;

                    // Änderungen speichern
                    package.Save();
                    Console.WriteLine($"Eingabe '{input}' in die Datei geschrieben.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Fehler beim Schreiben in die Datei: " + ex.Message);
            }
            finally
            {
                mutex.ReleaseMutex(); // Mutex freigeben
            }
        }

        public static void ReadFromExcel()
        {
            while (!stopReading)
            {
                Thread.Sleep(5000); // Warte 5 Sekunden bevor erneut gelesen wird
                try
                {
                    mutex.WaitOne(); // Mutex erwerben, um exklusiven Zugriff zu gewährleisten

                    // Aktuellen Dateiinhalt lesen und in der Konsole anzeigen
                    FileInfo fileInfo = new FileInfo(filePath);
                    using (ExcelPackage package = new ExcelPackage(fileInfo))
                    {
                        ExcelWorksheet worksheet = package.Workbook.Worksheets[0];
                        Console.Clear(); // Konsole leeren, um den aktuellen Dateiinhalt anzuzeigen
                        Console.WriteLine($"Aktueller Inhalt der Datei '{Path.GetFileName(filePath)}':");
                        Console.WriteLine("-------------------------------------");

                        for (int row = 1; row <= worksheet.Dimension.Rows; row++)
                        {
                            Console.WriteLine(worksheet.Cells[row, 1].Text);
                        }

                        Console.WriteLine("-------------------------------------");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Fehler beim Lesen der Datei: " + ex.Message);
                }
                finally
                {
                    mutex.ReleaseMutex(); // Mutex freigeben
                }
            }
        }

        static void Main(string[] args)
        {
            // Lizenz für EPPlus aktivieren
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            // Thread für die Konsoleneingabe und das Schreiben in die Excel-Datei
            Thread writeThread = new Thread(() =>
            {
                while (true)
                {
                    Console.WriteLine("Geben Sie einen Text ein (Geben Sie 'exit' ein, um zu beenden):");
                    string input = Console.ReadLine();

                    if (input.ToLower() == "exit")
                    {
                        stopReading = true; // Signal to stop the reading thread
                        break;
                    }

                    WriteToExcel(input);
                }
            });

            // Thread für das periodische Lesen der Excel-Datei und Anzeigen des Inhalts
            Thread readThread = new Thread(ReadFromExcel);

            // Starten der Threads
            writeThread.Start();
            readThread.Start();

            // Warten, bis der Schreib-Thread beendet ist
            writeThread.Join();

            // Warten, bis der Lese-Thread beendet ist
            readThread.Join();

            Console.WriteLine("Konsolen-Thread beendet.");
        }
    }
}