﻿using System;

namespace Fahrzeugverwaltungssystem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
