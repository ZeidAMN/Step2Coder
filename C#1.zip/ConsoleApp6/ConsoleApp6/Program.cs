﻿using System;

namespace ConsoleApp6
{
    internal class Program
    {
        public static void Fight(string enemy)
        {
            int healthpoints_me;
            int healthpoints_enemy;
            int enemy_damage;

            healthpoints_me = 500;

            if (enemy == "Zombie")
            {
                healthpoints_enemy = 250;
                enemy_damage = 10;
            }
            else if (enemy == "Witch")
            {
                healthpoints_enemy = 350;
                enemy_damage = 25;
            }
            else if (enemy == "Vampire")
            {
                healthpoints_enemy = 400;
                enemy_damage = 30;
            }
            else
            {
                Console.WriteLine("Invalid enemy choice.");
                return;
            }



            static void Main(string[] args)
            {
                Console.WriteLine("Welcome to The Nightmare - Choose your opponent: Zombie, Witch, Vampire");
                string enemy = Console.ReadLine();

                Fight(enemy);

                Console.WriteLine("Game Over. Press any key to exit.");
                Console.ReadKey();
            }
        }
    }
}