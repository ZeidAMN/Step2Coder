import matplotlib.pyplot as plt
import numpy as np
 
# Daten für die Plots
x = np.linspace(0, 10, 100)
y1 = x
y2 = x**2
y3 = np.sin(x)
categories = ['A', 'B', 'C', 'D', 'E']
values = [3, 7, 8, 5, 2]
labels = ['Äpfel', 'Bananen', 'Kirschen', 'Datteln']
sizes = [30, 20, 25, 25]
data = np.random.randn(1000)
scatter_x = np.random.rand(50)
scatter_y = np.random.rand(50)
 
# Erstellen eines Figure-Objekts und von Subplots
fig, axs = plt.subplots(3, 2, figsize=(15, 15))
 
# Liniengrafik
axs[0, 0].plot(x, y1, label='y = x')
axs[0, 0].plot(x, y2, label='y = x^2')
axs[0, 0].set_xlabel('X-Werte')
axs[0, 0].set_ylabel('Y-Werte')
axs[0, 0].set_title('Liniengrafik')
axs[0, 0].legend()
 
# Balkendiagramm
axs[0, 1].bar(categories, values, color='skyblue')
axs[0, 1].set_xlabel('Kategorien')
axs[0, 1].set_ylabel('Werte')
axs[0, 1].set_title('Balkendiagramm')
 
# Kreisdiagramm
axs[1, 0].pie(sizes, labels=labels, autopct='%1.1f%%', startangle=140)
axs[1, 0].set_title('Kreisdiagramm')
 
# Histogramm
axs[1, 1].hist(data, bins=30, edgecolor='black', color='lightgreen')
axs[1, 1].set_xlabel('Werte')
axs[1, 1].set_ylabel('Häufigkeit')
axs[1, 1].set_title('Histogramm')
 
# Scatter-Plot
axs[2, 0].scatter(scatter_x, scatter_y, color='red')
axs[2, 0].set_xlabel('X-Werte')
axs[2, 0].set_ylabel('Y-Werte')
axs[2, 0].set_title('Scatter-Plot')
 
# Einfache Sinusfunktion
axs[2, 1].plot(x, y3, color='purple')
axs[2, 1].set_xlabel('X-Werte')
axs[2, 1].set_ylabel('sin(X)')
axs[2, 1].set_title('Sinusfunktion')
 
# Layout anpassen und anzeigen
plt.tight_layout()
plt.show()
 
