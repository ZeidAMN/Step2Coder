﻿
/*
int choice;             // deklaration
double price;           
int bread_number;
double bread_price;
int milk_number;
double milk_price;
int coffee_number;
double coffee_price;
int cigarettes_number;
double cigarettes_price;
int age;
double number1, number2, number3,
        
bread_price = 2.25;         
milk_price = 1.75;              // difinition
coffee_price = 2.50;
cigarettes_price = 6.40;

do
{
    start:
    Console.WriteLine("Welcome to The Store - press 1 for Bread or press 2 for Milk or press 3 for Coffee or 4 for some Cigaretts or 5 to exit");
    choice = Convert.ToInt32(Console.ReadLine());


    switch (choice)
    {
            case 1:
            Console.WriteLine("How many Bread would you like?");
            bread_number = Convert.ToInt32(Console.ReadLine());
            price = bread_number * bread_price;
            Console.WriteLine("Your total is " + price);
            break;

            case 2:
            Console.WriteLine("How many Milk would you like?");
            milk_number = Convert.ToInt32(Console.ReadLine());
            price = milk_number * milk_price;
            Console.WriteLine("Your total is " + price);
            break;

            case 3:
            Console.WriteLine("How many Coffee would you like?");
            coffee_number = Convert.ToInt32(Console.ReadLine());
            price = coffee_number * coffee_price;
            Console.WriteLine("Your total is " + price);
            break;

            case 4:
            Console.WriteLine("How old are you?");
            age = Convert.ToInt32(Console.ReadLine());
            if (age > 18)
            {
                Console.WriteLine("The age Matches with the system");
                Console.WriteLine("How many Cigarettes would you like?");
                cigarettes_number = Convert.ToInt32(Console.ReadLine());
                price = cigarettes_number * cigarettes_price;
                Console.WriteLine("Your total is " + price);
            }
            else
            {
                Console.WriteLine("Your under age no Cigarettes for you");
                goto start;
                break;
            }
            



    }
}

while (choice != 5);

*/




int auswahl;
int i;    // i ist eine zahlvariable .... counter ....
int noten;
double zahl;  // deklaration 
int rauchen;


double summe;
double durchschnitt;

int [] zahlen = new int [3];        // Deklaration
string[] gamecharacters = new string [3];   // Deklaration
int anzahl;

summe = 0;

do
{

    Console.WriteLine("Willkommen zu meinem Notendurchschnittsprogramm");
    Console.WriteLine("Drücke 1 für Notendurchschnitt 2 für durchschnittlichen Zigarettenkonsum 3 für xxx 4 für xx 5 für xx 6 für Kunden 7 für Exit");
    auswahl = Convert.ToInt32(Console.ReadLine());

    switch (auswahl)
    {

        case 1:

            Console.WriteLine("Von wie viele Noten willst du den Durchschnitt berechnen?");
            noten = Convert.ToInt32(Console.ReadLine());

            // Erste Teil sagt mir wo fange ich an zu zahlen
            // Zweite Teil wie lange soll ich zählen.. (Limit)
            // Dritte Teil 
            for (i = 0; i < noten; i++)
            {
                Console.WriteLine("Bitte gib mir ein zahl");
                zahl = Convert.ToDouble(Console.ReadLine());

                summe += zahl;

            }
            durchschnitt = summe / noten;
            Console.WriteLine("Der Durchschnitt beträgt " + durchschnitt);
            break;


        case 2:
            Console.WriteLine("Bitte gib an, wie viele Wochentage du geraucht hast");
            rauchen = Convert.ToInt32(Console.ReadLine());

            for (i = 0; i < rauchen; i++)
            {
                Console.WriteLine("Bitte gib die Anzahl der Zigaretten für Tag " + (i + 1) + " ein");
                zahl = Convert.ToDouble(Console.ReadLine());

                summe += zahl;

            }

            Console.WriteLine("Die durchschnittliche Anzahl der gerauchten Zigaretten pro Tag beträgt " + summe);
            break;

            case 3:
            break;

            case 4:
            // von 100 nach 1 zählen mittels für schleife ..
            // 100 99 98 97 .......
            Console.WriteLine("Hier sind die Zahlen von 100 bis 1:");

            for (int num = 100; num >= 1; num--)
            {
                Console.WriteLine(num);
            }

            break;

        case 5:
            break;


        case 6:

            Console.WriteLine("Wie viele Kunden haben Sie");
            anzahl = Convert.ToInt32(Console.ReadLine());

            string[] kunden = new string[anzahl];
            // befüllen von meinem Array
            for (i=0; i<anzahl; i++)
            {
                Console.WriteLine("Bitte gib mir deinen Kunden");
                kunden[i] = Console.ReadLine();


            }



            break;

    }
} while (auswahl != 7);




