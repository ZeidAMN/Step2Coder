class Book:
    def __init__(self, title, author, year):
        self.title = title
        self.author = author
        self.year = year
 
    def __str__(self):
        return f"'{self.title}' von {self.author}, {self.year}"
 
class Library:
    def __init__(self):
        self.books = []
 
    def add_book(self, title, author, year):
        new_book = Book(title, author, year)
        self.books.append(new_book)
        print(f"Buch hinzugefuegt: {new_book}")
 
    def list_books(self):
        if not self.books:
            print("\nKeine Buecher in der Bibliothek.")
        else:
            print("\nListe der Buecher in der Bibliothek:")
            print("-" * 40)
            for book in self.books:
                print(book)
            print("-" * 40)
 
    def delete_book(self, title):
        book_to_delete = None
        for book in self.books:
            if book.title == title:
                book_to_delete = book
                break
        if book_to_delete:
            self.books.remove(book_to_delete)
            print(f"\nBuch geloescht: {book_to_delete}")
        else:
            print(f"\nKein Buch mit dem Titel '{title}' gefunden.")
 
# Hauptprogramm
def main():
    library = Library()
    while True:
        print("\n" + "=" * 40)
        print("           Buchverwaltungssystem           ")
        print("=" * 40)
        print("1. Buch hinzufuegen")
        print("2. Liste der Buecher anzeigen")
        print("3. Buch loeschen")
        print("4. Beenden")
        print("=" * 40)
        choice = input("Waehle eine Option (1-4): ")
        if choice == '1':
            title = input("\nTitel des Buches: ")
            author = input("Autor des Buches: ")
            year = input("Jahr der Veroeffentlichung: ")
            library.add_book(title, author, year)
        elif choice == '2':
            library.list_books()
        elif choice == '3':
            title = input("\nTitel des zu loeschenden Buches: ")
            library.delete_book(title)
        elif choice == '4':
            print("\nProgramm beendet.")
            break
        else:
            print("\nUngueltige Option, bitte waehle eine Option von 1 bis 4.")
 
if __name__ == "__main__":
    main()