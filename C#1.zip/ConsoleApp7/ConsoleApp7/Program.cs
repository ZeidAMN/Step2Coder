﻿using System;

namespace ConsoleApp6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int z1 = 10;
            int z2 = 26;
            int z3 = 4;

            // Sorting the numbers
            if (z1 > z2)
            {
                int temp = z1;
                z1 = z2;
                z2 = temp;
            }
            if (z2 > z3)
            {
                int temp = z2;
                z2 = z3;
                z3 = temp;

                // After swapping, check z1 and z2 again
                if (z1 > z2)
                {
                    int anotherTemp = z1;
                    z1 = z2;
                    z2 = anotherTemp;
                }
            }

            // Now z1, z2, z3 are sorted from smallest to largest
            Console.WriteLine($"Sorted numbers: {z1}, {z2}, {z3}");
        }
    }
}
