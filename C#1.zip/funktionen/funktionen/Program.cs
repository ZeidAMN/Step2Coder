﻿using System;

namespace ConsoleApp5
{
    internal class Program
    {
        public static void print_menu()
        {
            Console.WriteLine(" press 1 for game start press 2 for blabla ");
            Console.WriteLine(" press 1 for game start press 2 for blabla ");
            Console.WriteLine(" press 1 for game start press 2 for blabla ");
            Console.WriteLine(" press 1 for game start press 2 for blabla ");
            Console.WriteLine(" press 1 for game start press 2 for blabla ");
            Console.WriteLine(" press 1 for game start press 2 for blabla ");

        }

        public static void calculation()
        {
            double num1, num2, num3, avg;
            Console.WriteLine("Give me the first number");
            num1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Give me the second number");
            num2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Give me the third number");
            num3 = Convert.ToDouble(Console.ReadLine());

            avg = (num1 + num2 + num3) / 3;

            Console.WriteLine("the average is " + avg);



        }

        public static double calculation2()
        {
            double num1, num2, num3, avg;
            Console.WriteLine("Give me the first number");
            num1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Give me the second number");
            num2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Give me the third number");
            num3 = Convert.ToDouble(Console.ReadLine());

            avg = (num1 + num2 + num3) / 3;

            // Console.WriteLine("the average is " + avg);

            return avg;


        }

        public static double avg_calculation3(double num1, double num2, double num3)    // parameter 
        {
            double avg;

            // geliefert das wegen braucht mann nicht

            avg = (num1 + num2 + num3) / 3;

            // Console.WriteLine("the average is " + avg);

            return avg;


        }

        public static void calculation4(double num1, double num2, double num3)    // parameter 
        {
            double avg;

            // geliefert das wegen braucht mann nicht

            avg = (num1 + num2 + num3) / 3;

            Console.WriteLine("the average is " + avg);


        }


        // es gibt immer nur 1 Main!!
        static void Main(string[] args)
        {
            // print_menu();       // funktionsaufruf  function call für c# gibt man public static void name..()
            double result;          // deklaration
            double num1, num2, num3;

            // calculation(); // der aufruf einer void funktion

            // speichert die aufgabe in result
            // 2. variante
            //result = calculation2(); // aufruf mit rückgabewert
            //Console.WriteLine("the average is " + result);

            // 3. variante
            Console.WriteLine("Give me the first number");
            num1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Give me the second number");
            num2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Give me the third number");
            num3 = Convert.ToDouble(Console.ReadLine());

            result = avg_calculation3(num1, num2, num3);        //funktions aufruf

        }
    }
}