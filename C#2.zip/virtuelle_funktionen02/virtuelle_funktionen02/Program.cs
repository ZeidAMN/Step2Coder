﻿using System;

namespace virtuelle_funktionen02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            GameCharacter gc1 = new GameCharacter("Hero", 1, 150, "Invisibility");
            GameCharacter gc2 = new GameCharacter("Villain", 2, 120, "Strength");

            Console.WriteLine("Initial Data:");
            gc1.printData();
            gc2.printData();

            Console.WriteLine("\nGameCharacter Fight:");
            GameController.fight(gc1, gc2);

            SuperheroVillain hero = new SuperheroVillain("Superhero", 3, 200, "Flight");
            Enemy enemy = new Enemy("Enemy", 4, 80, "Poison");

            Console.WriteLine("\nNew Characters Created:");
            hero.printData();
            enemy.printData();

            Console.WriteLine("\nSuperheroVillain vs Enemy:");
            GameController.fight(hero, enemy);

            // Using GameController to create a new character
            GameCharacter gc3 = GameController.CreateGameCharacter("New Hero", 5, 180, "Telepathy");
            Console.WriteLine("\nNew Hero created via GameController:");
            gc3.printData();

            Console.WriteLine("\nNew Hero vs Original Hero:");
            GameController.fight(gc1, gc3);
        }
    }
}
