﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp9
{
    internal class Haus
    {
        public int groesse_in_m3;
        public int schlafzimmer;
        public int badezimmer;
        public int wc;
        public int kueche;
        public int gaeste_zimmer;
        public bool mit_garage;
        public bool mit_garten;




    }
}
