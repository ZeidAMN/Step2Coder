﻿
        int choice;
        double price;
        int bread_number;
        double bread_price;
        int milk_number;
        double milk_price;
        int coffee_number;
        double coffee_price;

        bread_price = 2.25;
        milk_price = 1.75;
        coffee_price = 2.50;

do
{

    Console.WriteLine("Welcome to The Store - press 1 for Bread or press 2 for Milk or press 3 for Coffee or 4 to exit");
    choice = Convert.ToInt32(Console.ReadLine());


    switch (choice)
    {
        case 1:
            Console.WriteLine("How many Bread would you like?");
            bread_number = Convert.ToInt32(Console.ReadLine());
            price = bread_number * bread_price;
            Console.WriteLine("Your total is " + price);
            break;

        case 2:
            Console.WriteLine("How many Milk would you like?");
            milk_number = Convert.ToInt32(Console.ReadLine());
            price = milk_number * milk_price;
            Console.WriteLine("Your total is " + price);
            break;

        case 3:
            Console.WriteLine("How many Coffee would you like?");
            coffee_number = Convert.ToInt32(Console.ReadLine());
            price = coffee_number * coffee_price;
            Console.WriteLine("Your total is " + price);
            break;




    }

    while (choice != 4) ;

}

