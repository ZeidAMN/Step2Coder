﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace virtuelle_funktionen02
{
    internal class GameController
    {
        public static GameCharacter CreateGameCharacter(string name, int id, int healthpoints, string special_ability)
        {
            return new GameCharacter(name, id, healthpoints, special_ability);
        }

        public static void fight(GameCharacter gc1, GameCharacter gc2)
        {
            Console.WriteLine("Fight starts between " + gc1.name + " and " + gc2.name);
            while (gc1.healthpoints > 0 && gc2.healthpoints > 0)
            {
                Thread thread1 = new Thread(() => gc1.fight(gc1, gc2));
                Thread thread2 = new Thread(() => gc2.fight(gc2, gc1));
                thread1.Start();
                thread2.Start();
                thread1.Join();
                thread2.Join();
                Thread.Sleep(1000); // Wait 0.5 second between rounds
            }
            if (gc1.healthpoints <= 0)
            {
                Console.WriteLine(gc1.name + " is defeated.");
            }
            if (gc2.healthpoints <= 0)
            {
                Console.WriteLine(gc2.name + " is defeated.");
            }
        }
    }
}
