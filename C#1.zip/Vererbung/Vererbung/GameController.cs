﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vererbung
{
    public static class GameController
    {

        public static void fight(Human h, SuperHuman s)
        {
            Console.WriteLine("i am fighting");


        }


    }
}
