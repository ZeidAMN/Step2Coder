﻿using System;

namespace ConsoleApp4
{
    internal class Program
    {
        // globale variable
        static double bierpreis;
        static string[] students = new string[5];       // Deklaration
        static void Main(string[] args)
        {
            int i;


            // füllen des Arrays
            for(i = 0; i < students.Length; i++)
            {
               Console.WriteLine("Give me the Students name");
                students[i] = Console.ReadLine();
            }


            // Ausgabe 
            /*
            for (i = 0; i < students.Length; i++)
            {
                Console.Write(students[i]);


            }

            // Alternative (gibt es nicht überall... java, C#, python)
            
            foreach (string student in students)
            {
                Console.WriteLine(student);
            }
            erste input
            */






        }
    }
}
