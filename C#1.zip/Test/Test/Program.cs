﻿
int choose;                 // Declaration
double price;
int hamsandwitch_number;
double hamsandwitch_price;
int vegiesandwitch_number;
double vegiesandwitch_price;
int chess_toast_number;
double chess_toast_price;

hamsandwitch_price = 3.79;              // Definition  
vegiesandwitch_price = 3.50;
chess_toast_price = 2.65;


do
{

    Console.WriteLine("Welcome to 24/7 Store - press 1 for Hamsandwitch or press 2 for Vegiesandwitch or 3 for Chess toast and 4 to exit");
    choose = Convert.ToInt32(Console.ReadLine());

    switch (choose)
    {
        case 1:
            Console.WriteLine("How many Hamsandwitch would you like?");
            hamsandwitch_number = Convert.ToInt32(Console.ReadLine());
            price = hamsandwitch_number * hamsandwitch_price;
            Console.WriteLine("Your total is " + price);
            break;


        case 2:
            Console.WriteLine("How many Vegiesandwitch would you like to buy?");
            vegiesandwitch_number = Convert.ToInt32(Console.ReadLine());
            price = vegiesandwitch_number * vegiesandwitch_price;
            Console.WriteLine("Your total is " + price);
            break;


        case 3:
            Console.WriteLine("How many Chess toast do you want to add");
            chess_toast_number = Convert.ToInt32(Console.ReadLine());
            price = chess_toast_number * chess_toast_price;
            Console.WriteLine("Your total is " + price);
            break;


        case 4:
            Console.WriteLine("Have a nice Day");
            break;


    }
} while (choose != 4);

