﻿int anzahl, i;
string kunden_suche;
bool kunden_existiert =false;

int auswahl;

Console.WriteLine("Willkommen zu meinem Notendurchschnittsprogramm");
Console.WriteLine("Drücke 1 für kundeneingabe 2 für sortieren und 3 suchen für 4 exit");
auswahl = Convert.ToInt32(Console.ReadLine());



switch (auswahl)
{
        case 1:

        Console.WriteLine("Wie viele Kunden haben Sie");
        anzahl = Convert.ToInt32(Console.ReadLine());

        string [] kunden = new string [anzahl];
        // befüllen von meinem Array

        for (i = 0; i < anzahl; i++) 
        {
            Console.WriteLine("bitte gib mir deinen Kunden ");
            kunden[i] = Console.ReadLine();

        }

        Console.WriteLine("Sortieren ");
        Array.Sort(kunden);

        for (i = 0; i < anzahl; i++) 
        {
            Console.WriteLine(kunden[i]);

        }



        Console.WriteLine("suchen ");
        Console.WriteLine("Gib die Kundennamen ein den du suchst:");
        kunden_suche = Console.ReadLine();

        for (i = 0; i < anzahl; i++)
        {
            
                if (kunden[i] == kunden_suche)
                {
                    kunden_existiert = true;
                    break;
                }

            

        }
        if (kunden_existiert)
        {
            Console.WriteLine("Die Kunde befindet sich in Unseren Liste");
        }
        else
        {
            Console.WriteLine("Die Kunde ist nicht in unseren Liste");
        }
        break;

        Console.WriteLine("rückwärts ");
        

        

}