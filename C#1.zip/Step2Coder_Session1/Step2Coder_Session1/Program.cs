﻿string name;  // string ist für wörter und variablen immmer klein
int age; // integer bedeutet ganze zahlen
int siblings;
int classgroup;
int shoes;
int cars;
int ps;
string videogames;
string pc;
int scale;
int beers;

Console.WriteLine("Welcome to my app");

Console.WriteLine("What is your name?");
name = Console.ReadLine();
// Console.WriteLine("welcome to my app " +  name + " how are you ");



Console.WriteLine("How old are you?");
age = Convert.ToInt32( Console.ReadLine() );

if (age < 16)
{
    Console.WriteLine("Sorry, no beer for you");
    goto anfang;
}
if (age == 99)
{ Console.WriteLine("Free beer for you"); 

}
else
{
    Console.WriteLine("how many beer, do you want to purchase sir?");
    beers = Convert.ToInt32( Console.ReadLine() );


}

/*if (age < 18)
{
Console.WriteLine("You cannot enter the Club Sir");
}
if (age == 70)
{
Console.WriteLine("You may enter Sir & Free drink for you");
}
else
{
Console.WriteLine("You may enter Sir");
}
*/

/*int pin;

beginning:
Console.WriteLine("what is your pin");
pin = Convert.ToInt32( Console.ReadLine() );

if (pin == 1234)
{
Console.WriteLine("pin correct");
}
else
{
Console.WriteLine("sorry incorrect - try again");
goto beginning;
}
*/

/*int age;

beginning:
Console.WriteLine("what is your age");
age = Convert.ToInt32( Console.ReadLine() );

if (age == 111)
{
Console.WriteLine("oida das geht nicht");
Envirnoment.Exit(0)
}
else
{
Console.WriteLine("..");
}
*/

anfang:
Console.WriteLine("How many Siblings do you have?");
siblings = Convert.ToInt32( Console.ReadLine() );
if (siblings < 5)
{
    Console.WriteLine("Thats nice");
    goto hier;
}
if(siblings > 7)
{
    Console.WriteLine("I don´t believe you");
}
else
{
    Console.WriteLine("A Big Familie you have got");
}

hier:
Console.WriteLine("How many People are in your Class?");
classgroup = Convert.ToInt32( Console.ReadLine() );

Console.WriteLine("How many pair of Shoes do you own?");
shoes = Convert.ToInt32( Console.ReadLine() );

Console.WriteLine("How many cars do you own");
cars = Convert.ToInt32( Console.ReadLine() );
if (cars == 0)
    goto next;

Console.WriteLine("How much horsepower does your car have?");
ps = Convert.ToInt32( Console.ReadLine() );
next:
Console.WriteLine("Do you play any Videogames?");
videogames = Console.ReadLine();

Console.WriteLine("Do you own a PC?");
pc = Console.ReadLine();

Console.WriteLine("From a scale of 1 to 10 how would you rate your Job?");
scale = Convert.ToInt32( Console.ReadLine() );


double weight;   // Datentyp
Console.WriteLine("What is your weight");
weight = Convert.ToDouble( Console.ReadLine() );
Console.WriteLine(weight);

double height;
Console.WriteLine("How tall are you");
height = Convert.ToDouble( Console.ReadLine() );
Console.WriteLine(height);

double total;
Console.WriteLine("How much did the items cost");
total = Convert.ToDouble( Console.ReadLine() );





