﻿using System;
using System.Collections.Generic;

// beispiele Kundendatenbanken, 

namespace Collections_Einfuehrung
{
    internal class Program
    {
        static List<string> flughafen = new List<string>(); // Deklaration
        public static void print_flugzeuge(List<string> aircrafts)
        {
            foreach (string aircraft in aircrafts)
            {
                Console.WriteLine(aircraft);
            }

        }

        public static void flugzeuge_count(List<string> aircrafts)
        {
            int count = 0;
            foreach (string aircraft in aircrafts)
            {
                count++;
            }
            Console.WriteLine("Es gibt " + count + " Flugzeuge im unseren flughafen");

        }

        public static void search_flugzeuge(List<string> aircrafts)
        {
            string flugzeug_search;

            Console.WriteLine("Welches Flugzeug möchtest du suchen?");
            flugzeug_search = Console.ReadLine();

            // Ueberpruf ob der flugzeug ist in der liste
            if (aircrafts.Contains(flugzeug_search))
            {
                Console.WriteLine("Das Flugzeug " + flugzeug_search + " wurde in der Liste gefunden.");
            }
            else
            {
                Console.WriteLine("Das Flugzeug " + flugzeug_search + " wurde nicht in der Liste gefunden.");
            }

        }



        public static void delete_flugzeuge(List<string> aircrafts)
        {
            string flugzeug_to_delete;

            Console.WriteLine("Welchen Flugzeug möchtest du von die Liste entfernen?");
            flugzeug_to_delete = Console.ReadLine();

            bool deleted = aircrafts.Remove(flugzeug_to_delete);

            if (deleted)
            {
                Console.WriteLine("Das Flugzeug " + flugzeug_to_delete + " wurde aus der Liste entfernt\n");
                Console.WriteLine("Hier ist die aktualisierte Liste:\n");
                foreach (var aircraft in aircrafts)
                {
                    Console.WriteLine(aircraft);
                }
            }
            else
            {
                Console.WriteLine("Flugzeug existiert nicht in unseren Liste");
            }

        }

        public static void delete_and_replace(List<string> aircrafts)
        {
            delete_flugzeuge(flughafen);
            input_flugzeuge();
        }
        public static void input_flugzeuge()
        {
            string flugzeug;
            do
            {
                Console.WriteLine("Gib den Namens des Flugzeuges ein - geben sie ein x um die liste zu schlissen");
                flugzeug = Console.ReadLine();
                flughafen.Add(flugzeug);

            } while (flugzeug != "x");

            flughafen.RemoveAt(flughafen.Count - 1);
        }

        public static void flugzeuge_sortieren(List<string> aircrafts)
        {
            // Sortiere die Flugzeugnamen in der Liste
            aircrafts.Sort();

            // Gib die sortierte Liste der Flugzeugnamen aus
            Console.WriteLine("Flugzeuge sortiert:");
            foreach (var aircraft in aircrafts)
            {
                Console.WriteLine(aircraft);
            }
        }


        private static void Main(string[] args)
        {

            /*
             flughafen.Add("Lufthansa123");
            flughafen.Add("British Airways 22");
            flughafen.Add("SAS333");
            flughafen.Add("Turkish Airways444");
            */

            // wie können wir die konsole einlesen
            // Console.WriteLine
            // Console.ReadLine

            input_flugzeuge();
            // menue flugzeug suche, flugzeuge löschen, flugzeug zählen, flugzeug ausgeben... mittels funktionen
           

            // Ausgabe
            int auswahl;
            do
            {
                Console.ForegroundColor = ConsoleColor.Green;

                Console.WriteLine(" Menue Flugzeug ");
                Console.WriteLine(" 1 flugzeuge suchen, 2 flugzeuge löschen, 3 flugzeug zählen, 4 flugzeug ausgeben, 5 ein un ausgeben , 6 flugzeuge_sortieren, 7 exit");
                auswahl = Convert.ToInt32(Console.ReadLine());
                switch (auswahl)
                {
                        case 1:
                        search_flugzeuge(flughafen);
                        break;

                        case 2:
                        delete_flugzeuge(flughafen);
                        break;

                        case 3:
                        flugzeuge_count(flughafen);
                        break;

                        case 4:
                        print_flugzeuge(flughafen);  // function call ... funktionsaufruf
                        break;

                        case 5:
                        delete_and_replace(flughafen);
                        break ;

                        case 6:
                        flugzeuge_sortieren(flughafen);
                        break;

                        default:
                        Console.WriteLine("Ungültige Auswahl.Bitte wählen Sie erneut.");
                        break;
                }
            } while (auswahl != 7);

            //  Gibt aus unsere Liste
            /*
            foreach (string flugzeug in flughafen)
            {
                Console.WriteLine(flugzeug);
            }
            */
        }
    }
}